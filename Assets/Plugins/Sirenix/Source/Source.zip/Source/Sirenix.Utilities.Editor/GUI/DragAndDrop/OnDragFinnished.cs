#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="OnDragFinnished.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.Utilities.Editor
{
    /// <summary>
    /// This class is due to undergo refactoring.
    /// </summary>
    public delegate void OnDragFinnished(DropEvents dropEvent);
}
#endif