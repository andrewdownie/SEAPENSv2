#if UNITY_EDITOR
//-----------------------------------------------------------------------
// <copyright file="DelegateDrawer.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using UnityEditor;
    using UnityEngine;

    /// <summary>
    /// Delegate property drawer. This drawer is rather simplistic for now, and will receive significant upgrades in the future.
    /// </summary>
    [OdinDrawer]
    [DrawerPriority(0.51, 0, 0)] // Just above the regular valueconflict/null value drawers, as we handle that here
    public class DelegateDrawer<T> : OdinValueDrawer<T> where T : class
    {
        private static MethodInfo invokeMethodField;
        private static bool gotInvokeMethod;

        private static MethodInfo InvokeMethod
        {
            get
            {
                if (!gotInvokeMethod)
                {
                    invokeMethodField = typeof(T).GetMethod("Invoke");
                    gotInvokeMethod = true;
                }

                return invokeMethodField;
            }
        }

        /// <summary>
        /// See <see cref="OdinDrawer.CanDrawTypeFilter(Type)"/>.
        /// </summary>
        public override bool CanDrawTypeFilter(Type type)
        {
            return !type.IsAbstract && typeof(Delegate).IsAssignableFrom(type) && InvokeMethod != null;
        }

        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(IPropertyValueEntry<T> entry, GUIContent label)
        {
            Delegate del = (Delegate)(object)entry.SmartValue;
            GUIContent content = GUIHelper.TempContent((string)null);
            bool conflict = false;
            bool targetConflict = false;

            bool anyMethodsNull = false;
            bool anyMethodsNotNull = false;

            for (int i = 0; i < entry.ValueCount; i++)
            {
                Delegate del2 = (Delegate)(object)entry.Values[i];

                if (del2 != null && del2.Method == null)
                {
                    anyMethodsNull = true;
                }
                else
                {
                    anyMethodsNotNull = true;
                }
            }

            if (entry.ValueState == PropertyValueState.NullReference || (anyMethodsNull && !anyMethodsNotNull))
            {
                conflict = true;
                content.text = "Null";
            }
            else if (entry.ValueState == PropertyValueState.ReferenceValueConflict || anyMethodsNull)
            {
                conflict = true;
                content.text = "Multiselection Value Conflict";
            }
            else
            {
                MethodInfo method = del.Method;
                object target = del.Target;

                for (int i = 1; i < entry.ValueCount; i++)
                {
                    var otherDel = (Delegate)(object)entry.Values[i];

                    if (otherDel.Method != method)
                    {
                        conflict = true;
                    }

                    if (otherDel.Target != target)
                    {
                        targetConflict = true;
                    }
                }

                if (conflict)
                {
                    content.text = "Multiselection Method Conflict";
                }
                else
                {
                    content.text = method.DeclaringType.GetNiceFullName() + "." + method.GetFullName();

                    if (method.IsStatic)
                    {
                        content.text = "static " + content.text;
                    }
                }
            }

            bool renderTarget = del != null && !conflict && del.Target is UnityEngine.Object;

            content.text += " (" + typeof(T).GetNiceName() + ")";

            var rect = EditorGUILayout.GetControlRect();

            if (label != null)
            {
                rect = EditorGUI.PrefixLabel(rect, label);
            }

            if (GUI.Button(rect.Padding(-4, 0, 0, 0), content, EditorStyles.popup))
            {
                Popup(entry, rect);
            }

            if (renderTarget)
            {
                var obj = del.Target as UnityEngine.Object;

                bool previousMixedValue = EditorGUI.showMixedValue;
                {
                    if (targetConflict)
                    {
                        EditorGUI.showMixedValue = true;
                    }
                }

                UnityEngine.Object newTarget;

                GUILayout.BeginHorizontal();
                {
                    if (label != null)
                    {
                        GUILayout.Space(EditorGUIUtility.labelWidth);
                    }
                    rect = EditorGUILayout.GetControlRect();
                    newTarget = EditorGUI.ObjectField(rect.Padding(90, 0, 0, 0), obj, del.Method.DeclaringType, true);
                    GUI.Label(rect.SetWidth(90), GUIHelper.TempContent("Target"));
                }
                GUILayout.EndHorizontal();

                if (newTarget != null && newTarget != obj)
                {
                    var newDel = Delegate.CreateDelegate(del.GetType(), newTarget, del.Method);

                    for (int i = 0; i < entry.ValueCount; i++)
                    {
                        entry.Values[i] = (T)(object)newDel;
                    }
                }

                if (targetConflict)
                {
                    EditorGUI.showMixedValue = previousMixedValue;
                }
            }
        }

        private static void Popup(IPropertyValueEntry<T> entry, Rect rect)
        {
            Type returnType = InvokeMethod.ReturnType;
            Type[] parameters = InvokeMethod.GetParameters().Select(n => n.ParameterType).ToArray();

            GenericMenu menu = new GenericMenu();

            if (typeof(Component).IsAssignableFrom(entry.Property.Tree.TargetType))
            {
                menu.AddItem(new GUIContent("Null"), false, () =>
                {
                    for (int i = 0; i < entry.ValueCount; i++)
                    {
                        entry.Values[i] = null;
                    }

                    entry.ApplyChanges();
                });

                var targetComponents = entry.Property.Tree.WeakTargets.Cast<Component>().ToArray();
                var targetGos = targetComponents.Select(n => n.gameObject).Distinct().ToArray();
                var targetScenes = targetGos.Select(n => n.scene).Distinct().ToArray();
                if (entry.ValueCount == 1)
                {
                    var go = targetGos[0];

                    RegisterGameObject(menu, entry, "Self (" + go.name + ")", go, returnType, parameters);
                }

                // Find delegates on components in scene, if there's just one scene targeted
                if (targetScenes.Length == 1)
                {
                    foreach (var go in SceneRoots())
                    {
                        RegisterGameObject(menu, entry, "Scene/" + go.name, go, returnType, parameters);
                    }
                }
            }
            else if (typeof(ScriptableObject).IsAssignableFrom(entry.Property.Tree.TargetType) && entry.ValueCount == 1)
            {
                menu.AddItem(new GUIContent("Null"), false, () =>
                {
                    for (int i = 0; i < entry.ValueCount; i++)
                    {
                        entry.Values[i] = null;
                    }

                    entry.ApplyChanges();
                });

                ScriptableObject obj = entry.Property.Tree.WeakTargets[0] as ScriptableObject;
                RegisterUnityObject(menu, entry, obj.name, obj, returnType, parameters);
            }

            if (menu.GetItemCount() == 0)
            {
                menu.AddDisabledItem(new GUIContent("Delegates currently only support being inspected on Components (limited multi-selection) and ScriptableObjects (no multiselection)."));
            }

            menu.DropDown(rect);
        }

        private static void RegisterGameObject(GenericMenu menu, IPropertyValueEntry<T> entry, string path, GameObject go, Type returnType, Type[] parameters)
        {
            RegisterUnityObject(menu, entry, path + "/GameObject", go, returnType, parameters);

            foreach (var component in go.GetComponents<Component>())
            {
                RegisterUnityObject(menu, entry, path + "/Components/" + component.GetType().GetNiceName(), component, returnType, parameters);
            }

            for (int i = 0; i < go.transform.childCount; i++)
            {
                var child = go.transform.GetChild(i).gameObject;

                RegisterGameObject(menu, entry, path + "/Children/" + child.name, child, returnType, parameters);
            }
        }

        private static void RegisterUnityObject(GenericMenu menu, IPropertyValueEntry<T> entry, string path, UnityEngine.Object obj, Type returnType, Type[] parameters)
        {
            MethodInfo[] methods = obj.GetType()
                                      .GetAllMembers<MethodInfo>(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance)
                                      .Where(n =>
                                      {
                                          if (n.ReturnType != returnType)
                                          {
                                              return false;
                                          }

                                          var methodParams = n.GetParameters();

                                          if (methodParams.Length != parameters.Length)
                                          {
                                              return false;
                                          }

                                          for (int i = 0; i < methodParams.Length; i++)
                                          {
                                              if (methodParams[i].ParameterType != parameters[i])
                                              {
                                                  return false;
                                              }
                                          }

                                          return true;
                                      })
                                      .ToArray();

            foreach (var method in methods)
            {
                string name = method.GetFullName();
                MethodInfo closureMethod = method; // For lambda capture

                //if (method.DeclaringType != obj.GetType())
                //{
                name += " (" + method.DeclaringType.GetNiceFullName() + ")";
                //}

                if (method.IsStatic)
                {
                    name += " (static)";
                }

                GenericMenu.MenuFunction func = () =>
                {
                    Delegate del;

                    if (closureMethod.IsStatic)
                    {
                        del = Delegate.CreateDelegate(typeof(T), null, closureMethod);
                    }
                    else
                    {
                        del = Delegate.CreateDelegate(typeof(T), obj, closureMethod);
                    }

                    for (int i = 0; i < entry.ValueCount; i++)
                    {
                        entry.Values[i] = (T)(object)del;
                    }

                    entry.ApplyChanges();
                };

                menu.AddItem(new GUIContent(path + "/" + name), false, func);
            }
        }

        public static IEnumerable<GameObject> SceneRoots()
        {
            var prop = new HierarchyProperty(HierarchyType.GameObjects);
            var expanded = new int[0];
            while (prop.Next(expanded))
            {
                yield return prop.pptrValue as GameObject;
            }
        }
    }
}
#endif